// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:tahaflutterapp/src/ui/splash.dart';

import 'src/ui/home.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
          primaryColor: Color(0xff003262), fontFamily: 'NotoKufiArabic'),
      home:
          Directionality(textDirection: TextDirection.rtl, child: SplashViw()),
    );
  }
}
