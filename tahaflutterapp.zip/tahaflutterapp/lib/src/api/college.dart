class CollegeData {
  var data = {
    {
      "id": 1,
      "name": "الكلية التقنية الهندسية موصل",
      "image": "asset/collage1.png",
      "place": [
        {
          "id": 1,
          "name": "موقف سيارات",
          "image_cover": "asset/ddddd.png",
          "content":
              "موقف سيارات للكلية التقنية الهندسية في الجامعة التقنية الشمالية مخصصص لسيارات الاساتذة والطلاب ",
        },
      ]
    },


     {
      "id": 2,
      "name": "الكلية التقنية الهندسية كركوك",
      "image": "asset/collage2.png",
      "place": [
        {
          "id": 1,
          "name": "موقف سيارات",
          "image_cover": "asset/ddddd.png",
          "content":
              "موقف سيارات للكلية التقنية الهندسية في الجامعة التقنية الشمالية مخصصص لسيارات الاساتذة والطلاب ",
        },
      ]
    },
  };
}
