// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

class AboutUI extends StatefulWidget {
  const AboutUI({Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() {
    return AboutState();
  }
}

class AboutState extends State<AboutUI> {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "حول التطبيق",
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
            ),
          ),
          backgroundColor: Theme.of(context).primaryColor,
          centerTitle: true,
          iconTheme: IconThemeData(color: Colors.white),
          elevation: 0,
        ),
        body: Directionality(
          textDirection: TextDirection.ltr,
          child: Padding(
              padding: EdgeInsets.only(
                top: 50,
              ),
              // ignore: unnecessary_new
              child: Column(
                children: [
                  Container(
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                              blurRadius: 10,
                              color: Colors.black.withOpacity(0.3))
                        ],
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white,
                      ),
                      alignment: Alignment.center,
                      width: MediaQuery.of(context).size.width - 30,
                      height: 130,
                      child: ListView(children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: SizedBox(
                            height: 200,
                            width: 200,
                            child: RichText(
                                textAlign: TextAlign.center,
                                // ignore: prefer_const_literals_to_create_immutables
                                text: TextSpan(children: [
                                  TextSpan(
                                    text: """دليل الجامعة التقنية الشمالية
هو تطبيق يسهل على الزائر البحث  على أماكن داخل الجامعة  مثل  القاعات ومختبرات والظائف والاخبار""",
                                    style: TextStyle(
                                      fontSize: 18,
                                      letterSpacing: 0.5,
                                      color: Colors.black,
                                      wordSpacing: 3,
                                    ),
                                  )
                                ])),
                          ),
                        ),
                      ])),
                  SizedBox(
                    height: 40,
                  ),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Expanded(
                            child: SizedBox(
                                height: 200,
                                width: 200,
                                child:
                                    Image.asset("asset/logo.png", scale: 1.1))),
                      ]),
                ],
              )),
        ),
      ),
    );
  }
}
