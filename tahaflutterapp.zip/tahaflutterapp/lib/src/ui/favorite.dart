// ignore_for_file: prefer_const_constructors

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:tahaflutterapp/src/ui/placeDetails.dart';

class FavoriteUI extends StatefulWidget {
  const FavoriteUI({Key? key}) : super(key: key);

  @override
  State<FavoriteUI> createState() => _WorkUIState();
}

class _WorkUIState extends State<FavoriteUI> {
  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          title: Text("المفضلة"),
          expandedHeight: 100,
          backgroundColor: Theme.of(context).primaryColor,
        ),
        SliverToBoxAdapter(
          child: Container(
            color: Theme.of(context).primaryColor,
            height: 40,
            width: MediaQuery.of(context).size.width,
            child: ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(40)),
              child: Container(
                child: Center(
                    child:
                        Opacity(opacity: 0.5, child: Text("اضغط على البطاقة"))),
                color: Colors.white,
                height: 40,
                width: MediaQuery.of(context).size.width,
              ),
            ),
          ),
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
              return GestureDetector(
                  child:
                      card('asset/Dddda.png', "موقف سيارات", index, context));
            },
            childCount: 1, // 1000 list items
          ),
        ),
      ],
    );
  }

  Widget card(String image, String name, int index, co) {
    return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Container(
          height: MediaQuery.of(co).size.height * 0.3,
          width: MediaQuery.of(co).size.width,
          decoration: BoxDecoration(),
          child: Stack(children: [
            SizedBox(height: 12),
            Positioned(
              top: 0,
              right: 15,
              child: Container(
                height: MediaQuery.of(co).size.height * 0.3,
                width: MediaQuery.of(co).size.width,
                decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      // BoxShadow(
                      //   offset: Offset(3, 3),
                      //   blurRadius: 0,
                      //   color: Colors.black.withOpacity(0.2),
                      // )
                    ],
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(35),
                      topRight: Radius.circular(6),
                    )),
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(name, style: TextStyle(color: Colors.black))),
              ),
            ),
            Positioned(
                top: 48,
                right: 15,
                left: 15,
                child: ClipRRect(
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0),
                    topLeft: Radius.circular(19),
                    bottomLeft: Radius.circular(19),
                    bottomRight: Radius.circular(19),
                  ),
                  child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(19),
                          boxShadow: [
                            BoxShadow(
                                offset: Offset(3, 3),
                                blurRadius: 5,
                                color: Colors.black.withOpacity(0.2))
                          ]),
                      height: 185,
                      width: MediaQuery.of(co).size.width - 20,
                      child: Image.asset(
                        image,
                        fit: BoxFit.fill,
                      )),
                )),
          ]),
        ));
  }
}
