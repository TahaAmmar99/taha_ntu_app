// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class WorkUI extends StatefulWidget {
  const WorkUI({ Key? key }) : super(key: key);

  @override
  State<WorkUI> createState() => _WorkUIState();
}

class _WorkUIState extends State<WorkUI> {


final Uri toLaunch =
        Uri(scheme: 'https', host: """www.ncciraqjobs.com""", path: '/index.php/jobseeker-control-panel/newest-jobs/st-15?lt=1');
  void _launchUrl() async {
  if (!await launchUrl(toLaunch)) throw """Could not launch www.ncciraqjobs.com/index.php/jobseeker-control-panel/newest-jobs/st-15?lt=1""";
}



  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
        slivers: [
          SliverAppBar(
            title: Text("توظيف"),
            expandedHeight: 100,
            backgroundColor : Theme.of(context).primaryColor,
           
          ) , 


           SliverToBoxAdapter(
                child: Container(
                  color: Theme.of(context).primaryColor,
                  height: 40,
                  width: MediaQuery.of(context).size.width,
                  child: ClipRRect(
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(40)),
                    child: Container(
                      child : Center(child: Opacity(opacity: 0.5,
                      child: Text("اضغط على البطاقة"))) ,
                      color: Colors.white,
                      height: 40,
                      width: MediaQuery.of(context).size.width,
                    ),
                  ),
                ),
              ),


               SliverList(
                 
          delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                 
                  width : MediaQuery.of(context).size.width - 20 ,
                 decoration: BoxDecoration(
                    borderRadius : BorderRadius.circular(10) ,
                    color : Colors.white,
                    boxShadow: [
                      BoxShadow( offset: Offset( 3,3) , blurRadius : 5 , color : Colors.black.withOpacity(0.2))
                    ]
                 ),

                 child : ListTile(
                   onTap: _launchUrl,
                   leading: Icon(Icons.open_in_browser),
                   title: Text(" الوظيفة  $index "),
                   subtitle: Text("تفاصيل العمل المطلوبة هي مبرمج تطبيقات يعمل بمختلف لغات البرمجة وقادر على ادارة السيرفات يجيد التعامل مع ووردبريس وجملا  وله خبرة اكثر من سنة  الرجاء ارسل الملف الشخصي ورقم الهاتف ونموذج اعمالك على الايميل في صفحة الخبر")
                 )
                ),
              ) ;
            },
            childCount: 1000, // 1000 list items
          ),
        ),
        ],
      ) ;
  }
}