import 'package:flutter/material.dart';

import 'home.dart';

class SplashViw extends StatefulWidget {
  const SplashViw({Key? key}) : super(key: key);

  @override
  State<SplashViw> createState() => _SplashViwState();
}

class _SplashViwState extends State<SplashViw> {
  @override
  void initState() {
    Future.delayed(Duration(seconds: 2), () {
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => const HomePage(),
          ));
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Stack(
          clipBehavior: Clip.hardEdge,
          children: [
            Positioned(
              top: -80,
              right: -110,
              child: Image.asset(
                'asset/Ellipse1.png',
                height: 300,
                // height: 200,
              ),
            ),
            Positioned(
              top: MediaQuery.of(context).size.height / 2.9,
              right: MediaQuery.of(context).size.width / 5,
              child: Image.asset(
                'asset/logo.png',
                height: 240,
                // height: 200,
              ),
            ),
            Positioned(
              bottom: -80,
              left: -110,
              child: Image.asset(
                'asset/Ellipse2.png',
                height: 300,
                // height: 200,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
