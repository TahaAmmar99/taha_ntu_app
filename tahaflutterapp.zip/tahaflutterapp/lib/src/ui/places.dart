// ignore_for_file: prefer_const_constructors

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:tahaflutterapp/src/ui/placeDetails.dart';
import 'package:tahaflutterapp/src/ui/search.dart';

class PlacesUI extends StatefulWidget {
  var data;
  PlacesUI({this.data, Key? key}) : super(key: key);

  @override
  State<PlacesUI> createState() => _WorkUIState();
}

class _WorkUIState extends State<PlacesUI> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(
                  bottom: Radius.circular(30),
                ),
              ),
              title: Text(widget.data["name"]),
              expandedHeight: 220,
              backgroundColor: Theme.of(context).primaryColor,
              flexibleSpace: Stack(children: [
                Positioned(
                  bottom: 100,
                  right: 50,
                  left: 50,
                  child: Container(
                      height: 50,
                      width: 120,
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(11)),
                      child: GestureDetector(
                        onTap: () {
                          showSearch(context: context, delegate: SearchUI());
                        },
                        child: Row(mainAxisAlignment: MainAxisAlignment.center,

                            // ignore: prefer_const_literals_to_create_immutables
                            children: [
                              // Padding(
                              //   padding: const EdgeInsets.all(2.0),
                              //   child: Icon(Icons.search),
                              // ),
                              Padding(
                                padding: const EdgeInsets.all(2.0),
                                child: Text("البحث"),
                              ),
                              // Padding(
                              //   padding: const EdgeInsets.all(2),
                              //   child: Icon(Icons.filter_list),
                              // )
                            ]),
                      )),
                ),
                Positioned(
                    bottom: 15,
                    right: 10,
                    left: 10,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  selectedIndex = 0;
                                });
                              },
                              child: Container(
                                  height: 60,
                                  width: 60,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Center(
                                      child: Image.asset("asset/car.png"))),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  selectedIndex = 1;
                                });
                              },
                              child: Container(
                                  height: 60,
                                  width: 60,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Center(
                                      child: Image.asset("asset/coffee.png"))),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  selectedIndex = 2;
                                });
                              },
                              child: Container(
                                  height: 60,
                                  width: 60,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Center(
                                      child:
                                          Image.asset("asset/book-open.png"))),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  selectedIndex = 3;
                                });
                              },
                              child: Container(
                                  height: 60,
                                  width: 60,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Center(
                                      child: Image.asset("asset/sketch.png"))),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: GestureDetector(
                              onTap: () {
                                setState(() {
                                  selectedIndex = 4;
                                });
                              },
                              child: Container(
                                  height: 60,
                                  width: 60,
                                  decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10)),
                                  child: Center(
                                      child: Image.asset("asset/library.png"))),
                            ),
                          ),
                        ],
                      ),
                    )),
              ]),
            ),

            //  SliverToBoxAdapter(
            //       child: Container(
            //         color: Theme.of(context).primaryColor,
            //         height: 40,
            //         width: MediaQuery.of(context).size.width,
            //         child: ClipRRect(
            //           borderRadius:
            //               const BorderRadius.vertical(top: Radius.circular(40)),
            //           child: Container(
            //             child : Center(child: Opacity(opacity: 0.5,
            //             child: Container( width: 20, child: Divider( thickness : 2, color: Theme.of(context).primaryColor)))) ,
            //             color: Colors.white,
            //             height: 40,
            //             width: MediaQuery.of(context).size.width,
            //           ),
            //         ),
            //       ),
            //     ),

            SliverList(
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int index) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 15),
                    child: GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PlacesDetailsUI(
                                  data: widget.data['place'][selectedIndex]
                                      [index])),
                        );
                      },
                      child: card(
                        widget.data['place'][selectedIndex][index]
                            ["image_cover"]!,
                        widget.data['place'][selectedIndex][index]["name"]!,
                        index,
                        context,
                      ),
                    ),
                  );
                },
                childCount: widget
                    .data['place'][selectedIndex].length, // 1000 list items
              ),
            ),
          ],
        ),
      ),
    );
  }

// Widget card(String image, String name, int index, co)
  Widget card(String image, String name, int index, co) {
    return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Container(
          height: MediaQuery.of(co).size.height * 0.3,
          width: MediaQuery.of(co).size.width,
          decoration: BoxDecoration(),
          child: Stack(children: [
            SizedBox(height: 12),
            Positioned(
              top: 0,
              right: 15,
              child: Container(
                height: MediaQuery.of(co).size.height * 0.3,
                width: MediaQuery.of(co).size.width,
                decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      // BoxShadow(
                      //   offset: Offset(3, 3),
                      //   blurRadius: 0,
                      //   color: Colors.black.withOpacity(0.2),
                      // )
                    ],
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(35),
                      topRight: Radius.circular(6),
                    )),
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(name, style: TextStyle(color: Colors.black))),
              ),
            ),
            Positioned(
                top: 48,
                right: 15,
                left: 15,
                child: ClipRRect(
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(0),
                    topLeft: Radius.circular(19),
                    bottomLeft: Radius.circular(19),
                    bottomRight: Radius.circular(19),
                  ),
                  child: Container(
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(19),
                          boxShadow: [
                            BoxShadow(
                                offset: Offset(3, 3),
                                blurRadius: 5,
                                color: Colors.black.withOpacity(0.2))
                          ]),
                      height: 185,
                      width: MediaQuery.of(co).size.width - 20,
                      child: Image.asset(
                        image,
                        fit: BoxFit.fill,
                      )),
                )),
          ]),
        ));
  }
}
