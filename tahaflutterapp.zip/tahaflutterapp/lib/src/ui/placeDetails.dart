// ignore: duplicate_ignore
// ignore: file_names
// ignore_for_file: prefer_const_constructors, file_names

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void _launchUrl(url) async {
  if (!await launchUrl(Uri.parse(url))) throw 'Could not launch $url';
}

class PlacesDetailsUI extends StatefulWidget {
  var data;
  PlacesDetailsUI({this.data, Key? key}) : super(key: key);

  @override
  State<PlacesDetailsUI> createState() => _WorkUIState();
}

class _WorkUIState extends State<PlacesDetailsUI> {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
                elevation: 10,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.vertical(
                    bottom: Radius.circular(30),
                  ),
                ),
                title: Text(widget.data["name"]),
                centerTitle: true,
                expandedHeight: 250,
                backgroundColor: Theme.of(context).primaryColor,
                flexibleSpace: ClipRRect(
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(15),
                      bottomRight: Radius.circular(15)),
                  child: Stack(
                    children: [
                      Positioned(
                          left: 0,
                          right: 0,
                          bottom: 0,
                          top: 0,
                          child: Image.asset(
                            widget.data["image_cover"],
                            fit: BoxFit.cover,
                          )),
                      Positioned(
                          bottom: 10,
                          left: 10,
                          child: Container(
                            height: 40,
                            width: 40,
                            child: IconButton(
                              onPressed: () {
                                _launchUrl(
                                    'https://www.google.com/maps/place/%D8%A7%D9%84%D9%83%D9%84%D9%8A%D8%A9+%D8%A7%D9%84%D8%AA%D9%82%D9%86%D9%8A%D8%A9+%D8%A7%D9%84%D9%87%D9%86%D8%AF%D8%B3%D9%8A%D8%A9%E2%80%AD/@36.3774743,43.1515599,17z/data=!3m1!4b1!4m5!3m4!1s0x4007953a27823193:0x6cb67c769d700082!8m2!3d36.3774743!4d43.1493712');
                              },
                              icon: Icon(Icons.location_pin,
                                  color: Theme.of(context).primaryColor),
                            ),
                            decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(40)),
                          )),
                      Positioned(
                          top: 60,
                          left: 10,
                          child: Container(
                            height: 40,
                            width: 40,
                            child: IconButton(
                              onPressed: () {},
                              icon: Icon(Icons.favorite, color: Colors.red),
                            ),
                            decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.7),
                                borderRadius: BorderRadius.circular(40)),
                          ))
                    ],
                  ),
                )),
            SliverFillRemaining(
              child: ListTile(
                  title: Text(widget.data["name"]),
                  subtitle: Text(widget.data["content"])),
            )
          ],
        ),
      ),
    );
  }
}
