// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:tahaflutterapp/src/ui/about.dart';
import 'package:tahaflutterapp/src/ui/favorite.dart';
import 'package:tahaflutterapp/src/ui/places.dart';
import 'package:tahaflutterapp/src/ui/search.dart';
import 'package:tahaflutterapp/src/ui/work.dart';
import 'package:url_launcher/url_launcher.dart';

import 'news.dart';
import 'problem.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List pages = [UniversityUI(), WorkUI(), FavoriteUI(), NewsUI()];
  int selectedPage = 0;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        bottomNavigationBar: ClipRRect(
            clipBehavior: Clip.antiAlias,
            borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(30.0),
                topRight: Radius.circular(20.0)),
            child: BottomNavigationBar(
                currentIndex: selectedPage,
                type: BottomNavigationBarType.fixed,
                unselectedItemColor: Theme.of(context).primaryColor,
                selectedItemColor: Colors.orange,
                iconSize: 25,
                onTap: (change) {
                  setState(() {
                    selectedPage = change;
                  });
                },
                // ignore: prefer_const_literals_to_create_immutables
                items: [
                  const BottomNavigationBarItem(
                    icon: Icon(Icons.home),
                    activeIcon: Icon(
                      Icons.home,
                    ),
                    label: "الرئيسية",
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.work),
                    activeIcon: Icon(Icons.work),
                    label: "توظيف",
                  ),
                  BottomNavigationBarItem(
                    icon: Icon(Icons.favorite_rounded),
                    activeIcon: Icon(
                      Icons.favorite_rounded,
                    ),
                    label: "المفضلة",
                  ),
                  const BottomNavigationBarItem(
                    icon: Icon(Icons.newspaper),
                    activeIcon: Icon(
                      Icons.newspaper,
                    ),
                    label: "الاخبار",
                  ),
                ])),
        drawer: Drawer(
            // ignore: avoid_unnecessary_containers
            child: Container(
                child: SingleChildScrollView(
                    child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor,
              ),
              height: 250,
              width: MediaQuery.of(context).size.width,
              child: Image.asset(
                "asset/logo.png",
                scale: 1.3,
                // width: 100,
              ),
            ),
            ListTile(
              onTap: () {
                launchUrl(Uri.parse(
                    'https://ntu.edu.iq/ar/%D8%A7%D9%84%D8%B1%D8%A6%D9%8A%D8%B3%D9%8A%D8%A9/'));
              },
              title: Text("موقع الجامعة التقنية الشمالية"),
              leading: Icon(Icons.web),
            ),
            ListTile(
              onTap: () {},
              title: Text("قيم التطبيق"),
              leading: Icon(Icons.rate_review),
            ),
            ListTile(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const AboutUI()),
                );
              },
              title: Text("حول المشروع"),
              leading: Icon(Icons.info),
            ),
            ListTile(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ProblemUI()),
                );
              },
              title: Text("ابلاغ عن مشكلة"),
              leading: Icon(Icons.feed),
            ),
          ],
        )))),
        body: pages[selectedPage],
      ),
    );
  }
}

var a = <List<Map<String, dynamic>>>[
  [
    {
      "id": 1,
      "name": "موقف سيارات",
      "image_cover": "asset/Dddda.png",
      "content":
          "تقع الكلية التقنية / الموصل في جانب المدينة الأيسر حيث أن نهر دجلة يقسم هذه المدينة التي تغفو على ضفاف هذا النهر الخالد إلى قسمين، موقع الكلية ينحصر بين صرحين علميين، جامعة الموصل من جهة والمعهد التقني في الموصل من الجهة الأخرى وتواجه الكلية بقايا من سور نينوى وبوابة نركال التي نشأت خلف أسوارها أقدم الحضارات وترعرعت وعاشت بين ظهرانيها بواكير العلم والمعرفة الأولى وخرجت عبر هذه البوابة رسل الأبجدية للعالم أجمع، ولا تزال بصمات علومها واضحة المعالم على أسوارها وجدرانها .",
    },
  ],
  [
    {
      "id": 1,
      "name": "نادي طلابي",
      "image_cover": "asset/nadi.jpg",
      "content":
          "تقع الكلية التقنية / الموصل في جانب المدينة الأيسر حيث أن نهر دجلة يقسم هذه المدينة التي تغفو على ضفاف هذا النهر الخالد إلى قسمين، موقع الكلية ينحصر بين صرحين علميين، جامعة الموصل من جهة والمعهد التقني في الموصل من الجهة الأخرى وتواجه الكلية بقايا من سور نينوى وبوابة نركال التي نشأت خلف أسوارها أقدم الحضارات وترعرعت وعاشت بين ظهرانيها بواكير العلم والمعرفة الأولى وخرجت عبر هذه البوابة رسل الأبجدية للعالم أجمع، ولا تزال بصمات علومها واضحة المعالم على أسوارها وجدرانها .",
    },
  ],
  [
    {
      "id": 1,
      "name": "مكتبة",
      "image_cover": "asset/library.jpg",
      "content":
          "تقع الكلية التقنية / الموصل في جانب المدينة الأيسر حيث أن نهر دجلة يقسم هذه المدينة التي تغفو على ضفاف هذا النهر الخالد إلى قسمين، موقع الكلية ينحصر بين صرحين علميين، جامعة الموصل من جهة والمعهد التقني في الموصل من الجهة الأخرى وتواجه الكلية بقايا من سور نينوى وبوابة نركال التي نشأت خلف أسوارها أقدم الحضارات وترعرعت وعاشت بين ظهرانيها بواكير العلم والمعرفة الأولى وخرجت عبر هذه البوابة رسل الأبجدية للعالم أجمع، ولا تزال بصمات علومها واضحة المعالم على أسوارها وجدرانها .",
    },
    {
      "id": 1,
      "name": "قاعة دجلة",
      "image_cover": "asset/2فه.png",
      "content":
          "تقع الكلية التقنية / الموصل في جانب المدينة الأيسر حيث أن نهر دجلة يقسم هذه المدينة التي تغفو على ضفاف هذا النهر الخالد إلى قسمين، موقع الكلية ينحصر بين صرحين علميين، جامعة الموصل من جهة والمعهد التقني في الموصل من الجهة الأخرى وتواجه الكلية بقايا من سور نينوى وبوابة نركال التي نشأت خلف أسوارها أقدم الحضارات وترعرعت وعاشت بين ظهرانيها بواكير العلم والمعرفة الأولى وخرجت عبر هذه البوابة رسل الأبجدية للعالم أجمع، ولا تزال بصمات علومها واضحة المعالم على أسوارها وجدرانها .",
    },
  ],
  [
    {
      "id": 1,
      "name": "مختبرات",
      "image_cover": "asset/lib.jpg",
      "content":
          "تقع الكلية التقنية / الموصل في جانب المدينة الأيسر حيث أن نهر دجلة يقسم هذه المدينة التي تغفو على ضفاف هذا النهر الخالد إلى قسمين، موقع الكلية ينحصر بين صرحين علميين، جامعة الموصل من جهة والمعهد التقني في الموصل من الجهة الأخرى وتواجه الكلية بقايا من سور نينوى وبوابة نركال التي نشأت خلف أسوارها أقدم الحضارات وترعرعت وعاشت بين ظهرانيها بواكير العلم والمعرفة الأولى وخرجت عبر هذه البوابة رسل الأبجدية للعالم أجمع، ولا تزال بصمات علومها واضحة المعالم على أسوارها وجدرانها .",
    },
  ],
  [
    {
      "id": 1,
      "name": "مكتبة",
      "image_cover": "asset/library.jpg",
      "content":
          "تقع الكلية التقنية / الموصل في جانب المدينة الأيسر حيث أن نهر دجلة يقسم هذه المدينة التي تغفو على ضفاف هذا النهر الخالد إلى قسمين، موقع الكلية ينحصر بين صرحين علميين، جامعة الموصل من جهة والمعهد التقني في الموصل من الجهة الأخرى وتواجه الكلية بقايا من سور نينوى وبوابة نركال التي نشأت خلف أسوارها أقدم الحضارات وترعرعت وعاشت بين ظهرانيها بواكير العلم والمعرفة الأولى وخرجت عبر هذه البوابة رسل الأبجدية للعالم أجمع، ولا تزال بصمات علومها واضحة المعالم على أسوارها وجدرانها .",
    },
  ],
];

// ignore: must_be_immutable
class UniversityUI extends StatelessWidget {
  UniversityUI({Key? key}) : super(key: key);

  List data = [
    {
      "id": 1,
      "name": "الكلية التقنية الهندسية موصل",
      "image": "asset/colleg1.png",
      "place": a
    },
    {
      "id": 2,
      "name": "الكلية التقنية الهندسية كركوك",
      "image": "asset/collage2.png",
      "place": a
    },
    {
      "id": 3,
      "name": "الكلية التقنية الزراعية ",
      "image": "asset/itz.jpg",
      "place": a
    },
    {
      "id": 4,
      "name": "الكلية التقنية ادراية",
      "image": "asset/itq.jpg",
      "place": a
    },
    {"id": 5, "name": "المعهد التقني", "image": "asset/itqq.jpg", "place": a},
  ];
  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          title: Text("الصفحة الرئيسية"),
          centerTitle: true,
          expandedHeight: 150,
          backgroundColor: Theme.of(context).primaryColor,
          flexibleSpace: Stack(children: [
            Positioned(
              bottom: 20,
              right: 50,
              left: 50,
              child: Container(
                  height: 50,
                  width: 120,
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(11)),
                  child: GestureDetector(
                    onTap: () {
                      showSearch(context: context, delegate: SearchUI());
                    },
                    child: Row(mainAxisAlignment: MainAxisAlignment.center,

                        // ignore: prefer_const_literals_to_create_immutables
                        children: [
                          // Padding(
                          //   padding: const EdgeInsets.all(8.0),
                          //   child: Icon(Icons.search),
                          // ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text("البحث"),
                          ),
                        ]),
                  )),
            ),
          ]),
        ),
        SliverToBoxAdapter(
          child: Container(
            color: Theme.of(context).primaryColor,
            height: 40,
            width: MediaQuery.of(context).size.width,
            child: ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(40)),
              child: Container(
                child: Center(
                    child: Opacity(
                        opacity: 0.5,
                        child: SizedBox(
                            width: 20,
                            child: Divider(
                                thickness: 2,
                                color: Theme.of(context).primaryColor)))),
                color: Colors.white,
                height: 40,
                width: MediaQuery.of(context).size.width,
              ),
            ),
          ),
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PlacesUI(data: data[index])),
                      );
                    },
                    child: card(data[index]["image"], data[index]["name"],
                        index, context)),
              );
            },
            childCount: data.length, // 1000 list items
          ),
        ),
      ],
    );
  }

  Widget card(String image, String name, int index, co) {
    return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Stack(children: [
          SizedBox(
            height: MediaQuery.of(co).size.height * 0.3,
            width: MediaQuery.of(co).size.width,
          ),
          SizedBox(height: 12),
          Positioned(
            top: 0,
            right: 10,
            child: Container(
              height: 55,
              width: 280,
              decoration: BoxDecoration(
                  color: ((index % 2) == 0)
                      ? Theme.of(co).primaryColor
                      : Colors.orange,
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(35),
                    topRight: Radius.circular(6),
                  )),
              child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(name, style: TextStyle(color: Colors.white))),
            ),
          ),
          Positioned(
              top: 48,
              right: 1,
              left: 10,
              child: ClipRRect(
                borderRadius: BorderRadius.only(
                  topRight: Radius.circular(0),
                  topLeft: Radius.circular(19),
                  bottomLeft: Radius.circular(19),
                  bottomRight: Radius.circular(19),
                ),
                child: SizedBox(
                    height: 185,
                    width: MediaQuery.of(co).size.width - 20,
                    child: Image.asset(
                      image,
                      fit: BoxFit.cover,
                    )),
              )),
        ]));
  }
}
