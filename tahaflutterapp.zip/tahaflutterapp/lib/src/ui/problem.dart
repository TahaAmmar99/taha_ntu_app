// ignore_for_file: prefer_const_constructors
import 'package:flutter/material.dart';

// import 'package:flutter/services.dart';

class ProblemUI extends StatefulWidget {
  const ProblemUI({Key? key}) : super(key: key);

  @override
  State<ProblemUI> createState() => _ProblemUIState();
}

class _ProblemUIState extends State<ProblemUI> {
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Theme.of(context).primaryColor,
          title: Text('البلاغ عن مشكلة'),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Container(
            alignment: Alignment.center,
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  height: 170,
                  child: Image.asset(
                    'asset/undraw_Messaging_fun_re_vic9.png',
                    scale: 1.0,
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  elevation: 5,
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'الاسم',
                      prefixIcon: Icon(
                        Icons.person,
                        color: Color(0xff003c68),
                      ),
                      border: OutlineInputBorder(
                         borderRadius: BorderRadius.circular(20),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Card(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  elevation: 5,
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'البريد الالكتروني',
                       border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                    ),
                      prefixIcon: Icon(
                        Icons.email,
                        color: Color(0xff003c68),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  margin: EdgeInsets.symmetric(horizontal: 5),
                  child: TextField(
                    maxLines: 7,
                    decoration: InputDecoration(
                      hintText: 'أكتب المشكلة',
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20)),
                    ),
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                TextButton(
                    style: TextButton.styleFrom(
                        backgroundColor: Color(0xff003c68),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        padding:
                            EdgeInsets.symmetric(horizontal: 25, vertical: 12)),
                    onPressed: () {},
                    child: Text(
                      'أرسال',
                      style: TextStyle(color: Colors.white, fontSize: 15),
                    ))
              ],
            ),
          ),
        ),
      ),
    );
  }
}
