// ignore_for_file: prefer_const_constructors

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

class NewsUI extends StatefulWidget {
  const NewsUI({Key? key}) : super(key: key);

  @override
  State<NewsUI> createState() => _WorkUIState();
}

class _WorkUIState extends State<NewsUI> {
  List data = [
    {
      "id": 1,
      "name": "السيدة رئيس الجامعة التقنية الشمالية تزور جامعة كركوك ",
      "image": "asset/sd.jpg",
      "content": """السيدة رئيس الجامعة التقنية الشمالية تزور جامعة كركوك ....
تنفيذاً لتوجيهات السيد معالي وزير التعليم العالي والبحث العلمي الأستاذ الدكتور نبيل كاظم عبد الصاحب في توطيد العلاقات بين الجامعات العراقية، قامت السيدة رئيس الجامعة التقنية الشمالية الأستاذ الدكتورة علياء عباس علي العطار على راس وفداً ضم السيد مساعد رئيس الجامعة للشؤون العلمية الأستاذ المساعد الدكتور عمر رافع محمود وعدد من مدراء الأقسام في رئاسة الجامعة بزيارة الى جامعة كركوك وبحضور السيد رئيس جامعة الكرخ للعلوم والسيد رئيس جامعة تكريت والسيد رئيس جامعة الحمدانية والأستاذ الدكتور عباس تقي رئيس جامعة كركوك سابقاً وكان في استقبالها السيد رئيس جامعة كركوك الأستاذ  والسادة مساعدا رئيس الجامعة والسيدات والسادة عمداء كليات جامعة كركوك ، جرى اثناء اللقاء بحث أطر التعاون المشترك في الجوانب العلمية وتبادل الخبرات والاتفاق على توقيع آلية تعاون مشترك لتعزيز النهوض بالواقع العلمي لكلا الجامعتين وعلى الأصعدة كافة وقد أشاد السيد رئيس جامعة كركوك  بالإدارة الحكيمة والمتميزة للسيدة رئيس الجامعة والجهود الكبيرة التي بذلتها وتبذلها سيادتها في خدمة الجامعة والمحافظات الثلاثة التي تقع فيها تشكيلات الجامعة وبدوره شكرت سيادتها السيد رئيس جامعة كركوك على حفاوة الاستقبال"""
    },
    {
      "id": 2,
      "name": " عقد هذا اليوم إجتماع مجلس الكلية التقنية الهندسية",
      "image": "asset/dsds.jpg",
      "content":
          """برئاسة السيد عميد الكلية الأستاذ المساعد الدكتور ماجد خليل نجم عقد هذا اليوم إجتماع مجلس الكلية التقنية الهندسية/ الموصل بجلسته الثالثة عشرة المفتوحة وبحضور السادة أعضاء المجلس كافة.
جرى خلال الجلسة مناقشة عدة أمور علمية وإدارية وطلابية نذكر منها:-
- متابعة الإمتحانات الفصلية لطلبة الدراسات العليا والدراسة الأولية والإلتزام بالتعليمات الوزارية."""
    },
  ];
  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          title: Text("اخبار"),
          expandedHeight: 100,
          backgroundColor: Theme.of(context).primaryColor,
        ),
        SliverToBoxAdapter(
          child: Container(
            color: Theme.of(context).primaryColor,
            height: 40,
            width: MediaQuery.of(context).size.width,
            child: ClipRRect(
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(40)),
              child: Container(
                child: Center(
                    child: Opacity(
                        opacity: 0.5,
                        child: Text("اضغط على الخبر للانتقال الى المصدر"))),
                color: Colors.white,
                height: 40,
                width: MediaQuery.of(context).size.width,
              ),
            ),
          ),
        ),
        SliverList(
          delegate: SliverChildBuilderDelegate(
            (BuildContext context, int index) {
              return Padding(
                padding: const EdgeInsets.all(8.0),
                child: Container(
                    width: MediaQuery.of(context).size.width - 20,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                              offset: Offset(3, 3),
                              blurRadius: 5,
                              color: Colors.black.withOpacity(0.2))
                        ]),
                    child: ListTile(
                        leading: Icon(Icons.open_in_browser),
                        title: Text(data[index]["name"],),
                        subtitle: Column(
                          children: [
                            Text(
                              data[index]["content"],
                              textAlign: TextAlign.right,
                            ),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(10),
                              child: SizedBox(
                                  height: 100,
                                  width:
                                      MediaQuery.of(context).size.width ,
                                  child: Image.asset(data[index]["image"] ,fit: BoxFit.cover,)),
                            )
                          ],
                        ))),
              );
            },
            childCount: data.length, // 1000 list items
          ),
        ),
      ],
    );
  }
}
