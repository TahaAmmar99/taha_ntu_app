// ignore_for_file: prefer_const_constructors,
import 'package:flutter/material.dart';

class SearchUI extends SearchDelegate<String> {
  final statelist = [
    'الكلية التقنية الهندسية موصل ',
    'الكلية التقنية الهندسية كركوك',
    'المعهد التقني موصل',
    'المعهد التقني كركوك',
    'قاعة المؤتمرات الكبرى',
    'موقف سيارات الكليتة التقنية موصل ',
    'مسجد الجامعة التقنية الشمالية في الموصل',

  ];
  final recentlist = [ 'الكلية التقنية الهندسية موصل ',
    'الكلية التقنية الهندسية كركوك',
    'المعهد التقني موصل',];

  @override
  List<Widget> buildActions(BuildContext context) {
    // action for app bar
    return [
      IconButton(
        onPressed: () {
          query = "";
        },
        icon: Icon(Icons.clear),
      )
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    // leading icon on the left of the app bar
    return IconButton(
      icon: AnimatedIcon(
        icon: AnimatedIcons.menu_arrow,
        progress: transitionAnimation,
      ),
      onPressed: () {
        close(context, "null");
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    
    return SizedBox(
      height: 150.0,
      child: Card(
        color: Colors.red,
        shape: StadiumBorder(),
        child: Text(query),
      ),
    );
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    final suggestionList = query.isEmpty
        ? recentlist
        : statelist.where((element) => element.startsWith(query)).toList();
    return ListView.builder(
      itemBuilder: (context, index) => ListTile(
          onTap: () {
            showResults(context);
          },
          title: RichText(
            text: TextSpan(
                text: suggestionList[index].substring(0, query.length),
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
                children: [
                  TextSpan(
                      text: suggestionList[index].substring(query.length),
                      style: TextStyle(color: Colors.grey))
                ]),
          )),
      itemCount: suggestionList.length,
    );
  }
}