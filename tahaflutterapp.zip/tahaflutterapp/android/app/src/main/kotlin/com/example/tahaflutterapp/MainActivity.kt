package com.example.tahaflutterapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
